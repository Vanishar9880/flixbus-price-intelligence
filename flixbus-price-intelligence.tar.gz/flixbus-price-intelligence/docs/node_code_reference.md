# Node Code Reference

All JavaScript code used in the N8N Code nodes, extracted for reference.

---

## Node 03 — Clean Data

```javascript
const cleaned = [];

for (const item of items) {
  const row = item.json;

  // Drop rows where Weighted Average Price is missing or empty
  const wap = parseFloat(row["Weighted Average Price"]);
  if (!row["Weighted Average Price"] || isNaN(wap)) continue;

  // Fill missing Number of Reviews with 0
  const reviewsRaw = row["Number of Reviews"];
  const reviews = (reviewsRaw !== undefined && reviewsRaw !== "")
    ? parseInt(reviewsRaw, 10)
    : 0;

  cleaned.push({
    json: {
      ...row,
      "Weighted Average Price": wap,
      "Number of Reviews": isNaN(reviews) ? 0 : reviews,
      "SRP Rank":        parseFloat(row["SRP Rank"]) || 0,
      "Available Seats": parseInt(row["Available Seats"], 10) || 0,
      "Total Seats":     parseInt(row["Total Seats"], 10) || 1,
      "Bus Score":       parseFloat(row["Bus Score"]) || 0
    }
  });
}

return cleaned;
```

---

## Node 04 — Derive Fields

```javascript
return items.map(item => {
  const row = item.json;

  // Load Factor = 1 - (Available Seats / Total Seats)
  const loadFactor = parseFloat(
    (1 - (row["Available Seats"] / row["Total Seats"])).toFixed(4)
  );

  // Departure Hour from "HH:MM" string or ISO timestamp
  const depStr = String(row["Departure Time"] || "");
  let departureHour = 0;
  if (depStr.includes(":") && !depStr.includes("T")) {
    departureHour = parseInt(depStr.split(":")[0], 10);
  } else if (depStr.includes("T")) {
    departureHour = new Date(depStr).getHours();
  }

  // Rank Bucket = ceil(SRP Rank / 5)
  const rankBucket = Math.ceil(row["SRP Rank"] / 5);

  // Similarity Group = RouteNumber_BusType_DepartureHour_RankBucket
  const simGroup = [
    String(row["Route Number"]).trim(),
    String(row["Bus Type"]).trim(),
    departureHour,
    rankBucket
  ].join("_");

  return {
    json: {
      ...row,
      "Load Factor":      loadFactor,
      "Departure Hour":   departureHour,
      "Rank Bucket":      rankBucket,
      "Similarity Group": simGroup
    }
  };
});
```

---

## Node 06 — Aggregate Competitors

```javascript
const groups = {};

for (const item of items) {
  const sg    = item.json["Similarity Group"];
  const price = parseFloat(item.json["Weighted Average Price"]);
  if (!sg || isNaN(price)) continue;

  if (!groups[sg]) {
    groups[sg] = { total: 0, count: 0 };
  }
  groups[sg].total += price;
  groups[sg].count += 1;
}

return Object.entries(groups).map(([sg, data]) => ({
  json: {
    "Similarity Group":     sg,
    "Competitor Avg Price": parseFloat((data.total / data.count).toFixed(2)),
    "Competitor Count":     data.count
  }
}));
```

---

## Node 08 — Calculate Price Difference

```javascript
return items.map(item => {
  const row      = item.json;
  const ourPrice = parseFloat(row["Weighted Average Price"]) || 0;
  const compAvg  = (row["Competitor Avg Price"] !== undefined && row["Competitor Avg Price"] !== null)
    ? parseFloat(row["Competitor Avg Price"])
    : null;

  let priceDiff    = null;
  let priceDiffPct = null;

  if (compAvg !== null && !isNaN(compAvg) && compAvg > 0) {
    priceDiff    = parseFloat((ourPrice - compAvg).toFixed(2));
    priceDiffPct = parseFloat(((priceDiff / compAvg) * 100).toFixed(2));
  }

  return {
    json: {
      ...row,
      "Price Difference":   priceDiff,
      "Price Difference %": priceDiffPct
    }
  };
});
```

---

## Node 09 — Apply Flag Logic

```javascript
return items.map(item => {
  const row = item.json;
  const pct = row["Price Difference %"];

  let flag = "No Competitor Data";

  if (pct !== null && pct !== undefined) {
    if      (pct >  10)  flag = "Too Expensive";
    else if (pct < -10)  flag = "Too Cheap";
    else                  flag = "OK";
  }

  return {
    json: {
      ...row,
      "Flag":     flag,
      "Run Date": new Date().toISOString().split("T")[0]
    }
  };
});
```

---

## Slack Alert Message Template

```
🚌 *Price Alert — {{ $json["Flag"] }}*

• *Route:*        `{{ $json["Route Number"] }}`
• *Bus Type:*     {{ $json["Bus Type"] }}
• *Departure:*    {{ $json["Departure Time"] }}
• *Our Price:*    €{{ $json["Weighted Average Price"] }}
• *Comp Avg:*     €{{ $json["Competitor Avg Price"] }}
• *Diff %:*       {{ $json["Price Difference %"] }}%
• *SRP Rank:*     {{ $json["SRP Rank"] }}
• *Load Factor:*  {{ $json["Load Factor"] }}
• *Sim Group:*    `{{ $json["Similarity Group"] }}`
• *Date:*         {{ $json["Run Date"] }}
```
